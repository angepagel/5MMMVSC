export CADP="/matieres/5MMMVSC7/Cadp"
export PATH="$CADP/com:$CADP/bin.`$CADP/com/arch`:$PATH"

